package com.exam;
@FunctionalInterface
public interface Findable {
     int find(int searchFor, int ... array);
}
