package com.exam;

@FunctionalInterface
public interface Sortable {
     int [] sort(int...array);
}
